### **Whimscape 1.20-1.20.1_r10** (2026 Sep 13)

- Added mod support: Crafting Tweaks button textures
- Changed fence models and textures to work better with the Diagonal Fences mod
- JEI: Added GUI texture: interactive_ingredient_tooltip_background

________________________________________________________________

### **Whimscape 1.20-1.20.1_r9** (2026 Jun 15)

- Added mod support: 
    - Punchy! compatibility files
    - Polytone sky/fog colors, birch leaf color, map colors for stone and water
    - Lanterns Belong on Walls
- Changed item model diagonal_rod_rotated: increased third-person scale to match the default handheld item model
- Removed item models of shovels

________________________________________________________________

### **Whimscape 1.20-1.20.1_r8** (2026 May 18)

- Fixed redstone dust dot texture having a semitransparent errant pixel
- Changed armor trims to use the default trim palette size
- Changed stonecutter textures slightly
- Changed entity textures:
    - Cats and ocelot touched up
    - Chicken beak and foot color adjusted
    - Horses, donkey, mule:
        - Adjusted details and shading
        - Changed white and black horse colors
        - Redesigned the "black dots" markings
    - Stray overlay color adjusted
    - Squid color changed
    - Piglins tweaked
    - Wolf tweaked
- Changed item textures:
    - Squid spawn egg
- Removed Illager Invasion armor trim compatibility asset (obsolete)
- Farmer's Delight:
    - Added block models:
        - Basket template (custom texture coordinates)
        - Gleaming salad (custom texture coordinates)
        - Some default models to keep compatibility with earlier versions of the mod
    - Added block textures:
        - Platter (rice roll medley)
        - Wooden basket
        - Gleaming salad
        - Rope fence
        - Rope fence gate
    - Added item textures:
        - Gleaming salad
        - Bowl of gleaming salad
        - Onion soup
    - Added cooking pot JEI widget texture
    - Fixed cabbage stages 0-2 not rendering
    - Fixed tomatoes on rope using default models
    - Fixed bamboo basket using default textures
    - Changed placeable food models/textures to better fit their new hitboxes
    - Changed basket textures slightly

________________________________________________________________

### **Whimscape 1.20-1.20.1_r7** (2026 Jan 17)

- Added LabPBR emissive textures for improved compatibility with the IPBR+ mode in Complementary Shaders
    - Enable these shader settings in Materials > IntegratedPBR+ Materials > Other IPBR+ Features:
        - IPBR+ Emissive Mode: labPBR > IPBR+
        - IPBR+ Compatibility Mode: On
- Added mod support:
    - Trade Cycling button texture
    - Chat Patches GUI textures
    - Cloth Config GUI textures
    - YetAnotherConfigLib color picker texture
    - JEI history button texture
    - Waystones: blackstone, deepslate and end stone waystone textures
- Added rails emissive texture for OptiFine/Continuity
- Added end portal texture
- Fixed missing textures when using platinum armor trims in the Illager Invasion mod
- Changed fire and campfire fire textures: removed darkest shade
- Changed item textures:
    - Horse armor: redesigned
    - Diamond items, lapis lazuli: changed outline color slightly
    - Nautilus shell
- Changed entity textures:
    - Spider custom models' leg textures tweaked
    - Allay eyes lowered by a pixel
    - Horse armor and saddles
    - Husk: color tweak
    - Skeleton and stray: new face design
    - Lead knot top face texture tweaked to match the sides
- Changed copper trim colors to match other copper
- Changed paintings: burning_skull, donkey_kong, pointer, skeleton, sunset, void
- Changed effect icons: darkness, saturation

________________________________________________________________

### **Whimscape 1.20-1.20.1_r6** (2025 May 20)
- Added soul lantern emissive texture
- Added waxed block item textures with a glint animation
- Fixed EMI mod support: added a missing sprite to widgets.png
- Changed GUI button disabled textures
- Changed block and item models:
    - Brewing stand bottles
    - Amethyst buds/cluster display tweaks
    - Lantern display tweaks
    - Replaced negative-sized elements in cauldrons, hoppers, open barrel and outlined blocks
    - Moved shield idle position in first person view to be less intrusive and better match its third person position
    - Waxed blocks: removed outline from items
- Changed block textures:
    - Brewing stand bottles
    - End portal frame eye
    - Lantern emissive texture
    - Sunflower
    - Torch flame animations
    - Composter, note block, jukebox, pitcher crop and scaffolding top: slight single-color tweak
- Changed item textures:
    - Chorus fruits
    - Cookie
    - Buckets
    - Sunflower
    - Torch flame animations
    - Minor tweaks to some other items
- Changed entity textures: tweaks to cow, ghast, shield and slime
- Changed paintings: earth, wind, fire, water
- Removed unused cauldron block models

________________________________________________________________

### **Whimscape 1.20-1.20.1_r5** (2025 Apr 20)
- Added mod support: TrashSlot
- Added grass block models to only rotate the top texture
- Added bamboo gate models and changed the texture
- Added animation to campfire item textures
- Fixed missing, redundant or incorrect texture and parent references in many models
- Fixed warnings about unused frames in conduit wind sprites by cropping them out
- Fixed small textures in the Waystones mod limiting mip level from 4 to 3
- Changed pig texture and custom model
- Changed chicken textures
- Changed slime entity texture slightly
- Changed conduit wind animation frametime from 3 to 1
- Changed fence and gate models: separated from default templates for mod compatibility
- Changed item textures: all books and smithing templates, spider eyes, egg, gold ingot
- Changed donkey, mule and zombie horse spawn egg textures: 1-pixel tweak
- Changed chestplate armor trim item overlay slightly

________________________________________________________________

### **Whimscape 1.20-1.20.1_r4** (2025 Apr 12)
- Added mod support: Waystones
- Added matching inventory models for wall blocks with custom texture mapping
- Added cherry leaves variant texture
- Changed cherry leaves texture slightly
- Changed pufferfish item texture colors slightly
- Changed dead bush block texture slightly
- Changed spawn eggs: tweaks to mooshroom and witch
- Removed textures/block/sand_s.png

________________________________________________________________

### **Whimscape 1.20-1.20.1_r3** (2024 Oct 26)
- Added mod support:
    - Dungeons and Taverns key item textures
    - Visuality particle textures
    - Mod Menu GUI textures
    - oωo library GUI textures
    - Entity Features config button textures
    - Roughly Enough Items (REI)
    - EMI
    - Fabric creative inventory page buttons texture
- Added missing Just Enough Items (JEI) textures
- Fixed errant pixel in fox and wolf spawn egg items
- Fixed tropical fish fin patterns being one-sided
- Changed some GUI elements
- Changed font glyphs: f, G, i, J, j, t, y and some Cyrillic characters
- Changed enchanted glint textures
- Changed many spawn egg items slightly
- Changed acacia leaves color slightly
- Changed grass and fern base texture colors: reduced saturation of darker shades
- Changed banner pattern item textures

________________________________________________________________

### **Whimscape 1.20-1.20.1_r2** (2024 Sep 30)
- Added redstone torch block models
- Added missing torch template block models
- Added comparator and repeater models (from 24w38a with UV tweaks)
- Added textures for comparator block's subtraction mode
- Changed wall torch block model slightly
- Changed redstone torch block and item textures
- Changed comparator and repeater textures slightly
- Changed bee spawn egg item texture: 1-pixel tweak
- Changed the colors of brown dye and brown candle item textures
- Changed wolf textures: lighter color
- Changed pitcher plant colors
- Changed sea lantern texture
- Changed guardian and elder guardian textures

________________________________________________________________

### **Whimscape 1.20-1.20.1_r1** (2024 Mar 19)
- Added custom spawn egg item textures
- Added mod support:
    - AppleSkin
    - Just Enough Items
    - Farmer's Delight
- Added wall torch model with a holder
- Fixed dolphin flipper texture orientation
- Changed buttons and sliders to a simpler design
- Changed recipe book craftable toggles slightly
- Changed food HUD icons: reduced size for clean AppleSkin outlines
- Changed fuel progress textures for a cleaner look
- Changed pumpkins: clean up and color adjustment
- Changed bee nest: partial redesign
- Changed honeycomb block and beehive: adjusted honey color
- Changed beetroots and potatoes: shading tweak on the tuber
- Changed crimson and warped stem tops: made distinct from regular logs
- Changed cake block slightly
- Changed mossy stone brick wall tops slightly
- Changed brewing stand rod texture and added emissive map
- Changed vindicator pants color
- Changed farmland textures slightly
- Changed pumpkin pie item: slight color adjustment
- Changed potions, experience bottle and dragon's breath bottle highlights
- Changed stone axe, stone hoe, stone shovel, wooden shovel and wooden axe slightly
- Changed cookie texture: made smaller
- Changed mutton and cooked mutton texture
- Changed bowl, stew and soup textures
- Changed bone and bone meal texture colors slightly

________________________________________________________________

### **Whimscape 1.20_r4** (2023 Dec 20)
- Backported changes up to 1.20.2-1.20.4_r1 (where applicable):

    - #### **Whimscape 1.20.2-1.20.4_r1** (2023 Dec 20)

        - Added gust particle textures
        - Added wind charge texture
        - Added armadillo texture
        - Added armadillo scute texture
        - Added wolf armor textures
        - Fixed turtle scute item texture name for snapshot 23w51a
        - Fixed breeze eyes for snapshot 23w51a
        - Changed the font's ampersand to be closer to the modern form
        - Changed potion textures
        - Changed dragon's breath texture
        - Changed experience bottle texture
        - Changed honey bottle texture
        - Changed flower pot item texture
        - Changed goat horn texture

    - #### **Whimscape 1.20.2-1.20.3_r1** (2023 Dec 5)

        - Added models and textures for the new experimental features
        - Added darkness effect icon texture
        - Added textures/gui/sprites/widget/slot_frame.png
        - Fixed bat texture for the new model in 1.20.3
        - Fixed short grass in 1.20.3
        - Fixed waxed slab outline missing down-facing texture
        - Fixed button block textures being flipped vertically
        - Changed infested and waxed blocks: slightly thinner item outlines
        - Changed raw copper block texture slightly
        - Changed tuff colors slightly
        - Removed leftover realms folder

    - #### **Whimscape 1.20.2_r1** (2023 Sep 26)

        - Added new icons in map_icons.png
        - Fixed GUI for 1.20.2
        - Changed structure_block_load and structure_block_save textures
        - Changed rail item outlines slightly
        - Changed gold and copper ingot textures for better distinction
        - Changed pack_format to 18

________________________________________________________________

### **Whimscape 1.20_r3** (2023 Jun 16)

- Added paintings: earth, fire, water, wind
- Fixed pot patterns: missing plenty pattern and incorrect prize texture

________________________________________________________________

### **Whimscape 1.20_r2** (2023 Jun 11)

- Fixed OptiFine applying a tint to cherry leaves
- Fixed sniffer egg stage inconsistencies
- Changed jungle door and trapdoor design
- Changed iron door slightly to better show orientation
- Changed some other doors: minor tweaks

________________________________________________________________

### **Whimscape 1.20_r1** (2023 Jun 7)

- Added sniffer and sniffer egg textures
- Added pitcher plant and torchflower blocks and items
- Added armor trims and templates: host, raiser, shaper, silence, wayfinder
- Added decorated pot textures
- Added item textures: brush, pottery sherds, "Relic" music disc
- Added suspicious gravel
- Added calibrated sculk sensor model and textures
- Fixed menu logos and invite_icon for the new texture layouts in 1.20
- Changed armor trims: dune, sentry
- Changed some smithing templates
- Changed cherry particles
- Changed suspicious sand slightly
- Changed bamboo and cherry doors and trapdoors
- Changed bamboo block top texture
- Changed pack_format to 15

________________________________________________________________

### **Whimscape 1.19.4_r1** (2023 Mar 15)

- Added 1.20 data pack features: armor trims, cherry things, suspicious sand
- Added world creation screen textures
- Added the new separate GUI slider texture
- Fixed smithing GUI textures and tweaked legacy GUI
- Changed some armor to work better with armor trims
- Changed enchanted glint slightly
- Changed pack_format to 13

________________________________________________________________

### **Whimscape 1.19.3_r8** (2023 Mar 12)

- Added custom wither model and tweaked wither skull
- Added sand and red sand variant
- Added dorianpb/cem folder for Fabric CEM, removing animations that break it
- Fixed witch missing textures when using Fabric CEM
- Fixed slight color inconsistency in empty armor slot textures
- Changed amethyst blocks to better match the custom amethyst cluster model
- Changed some pink colors slightly and tweaked pink glazed terracotta pattern
- Changed anvil GUI icon

________________________________________________________________

### **Whimscape 1.19.3_r7** (2023 Feb 19)

- Added 1.20 data pack features: bamboo stuff, chiseled bookshelf, hanging signs and camel
- Fixed nether wart missing break particles
- Fixed rogue pixel in kelp texture
- Fixed missing pixels in angry bee with nectar custom model
- Fixed Z-fighting in fish fins
- Changed bamboo stalk to better match new bamboo blocks
- Changed wandering trader custom model: added 3D pouches
- Changed pillager, witch, wolf and horse_creamy textures slightly
- Changed item frame backgrounds
- Changed loom, smithing table and stonecutter textures slightly
- Changed azalea blocks slightly
- Changed netherite: colors, sword to match tools better
- Changed ancient debris colors slightly
- Changed many items with minor color adjustments

________________________________________________________________

### **Whimscape 1.19.3_r6** (2023 Feb 5)

- Added custom bee model
- Added custom witch model
- Added axolotl bucket textures for different colors via CIT
- Added custom colors: fog.end, sky.end, map.stone, map.water, xp orb
- Added obsidian variant
- Added wither armor effect texture
- Added emissive texture for strider eyes
- Fixed creative inventory alignment with tabs
- Changed ore blocks to better distinguish different ores
- Changed enderman and endermite textures
- Changed many mobs with small tweaks
- Changed obsidian blocks and entities: mostly color tweaks
- Changed many blocks with minor color adjustments
- Changed minecart shading slightly
- Changed minecart items to use the actual minecart texture
- Changed some item textures slightly
- Changed some armor textures slightly
- Changed main menu logo colors slightly

________________________________________________________________

### **Whimscape 1.19.3_r5** (2023 Jan 15)

- Added custom models for chorus flower and plant
- Fixed mossy stone brick slabs and stairs not using variant textures
- Fixed drowned flipped arm and leg
- Fixed wolf collar Z-fighting with custom entity models enabled
- Fixed glass pane CTM not connecting properly in corners
- Changed glass and stained glass CTM to enable innerSeams
- Changed ice, packed ice and frosted ice textures and added variants
- Changed lever texture
- Changed hopper texture to make direction clear from above
- Changed stonecutter textures
- Changed smoker bottom texture
- Changed various other blocks slightly
- Changed many entity textures with small tweaks
- Changed pack.png slightly

________________________________________________________________

### **Whimscape 1.19.3_r4** (2023 Jan 5)

- Added custom models for pumpkin and melon stems
- Fixed netherite armor still using old textures in 1.19.3 releases
- Fixed door side UV inconsistency
- Fixed custom door models causing mod compatibility issues
- Changed lectern textures slightly
- Changed cactus bottom texture
- Changed some green colors slightly
- Removed unused door model files

________________________________________________________________

### **Whimscape 1.19.3_r3** (2022 Dec 23)

- Added unique enchanted book textures
    - requires OptiFine, Options/Video Settings/Quality/Custom Items: ON
- Changed all book item textures slightly
- Changed experience bottle and dragon's breath item textures: added glow outlines

________________________________________________________________

### **Whimscape 1.19.3_r2** (2022 Dec 17)

- Added CTM for glass, stained glass, glass pane and tinted glass
    - You can delete a block's folder in assets\minecraft\optifine\ctm if you prefer no CTM, or turn it off in video settings
- Changed glass and tinted glass colors slightly
- Changed nether gold ore texture slightly
- Changed iron block and iron trapdoor slightly
- Changed netherite block, ancient debris and lodestone colors
- Changed netherite armor: partial redesign for a more sinister feel
- Changed various items (mostly slight color tweaks)

________________________________________________________________

### **Whimscape 1.19.3_r1** (2022 Dec 7)

- Added textures/gui/checkbox.png
- Added textures/gui/report_button.png
- Added outline to waxed copper block items
- Added jigsaw block textures
- Fixed vex textures for the new 1.19.3 model
- Fixed missing transparency in allay texture
- Fixed creative inventory textures for 1.19.3
- Fixed boat item textures missing from atlases/blocks.json
- Fixed door UV inconsistencies
- Changed mangrove wood colors slightly
- Changed bookshelf content colors slightly
- Changed stripped log top texture by one pixel
- Changed OptiFine fog0 colormap slightly
- Changed pack_format to 12
- Removed some unused model files

________________________________________________________________

### **Whimscape 1.19_r2** (2022 Oct 8)

- Added CHANGELOG.md
- Added missing toasts.png icons
- Added missing stripped mangrove log textures
- Changed mangrove wood block colors to match boats and signs
- Removed unused glowstone .mcmeta file

________________________________________________________________

### **Whimscape 1.19_r1** (2022 Sep 29)

- Initial release