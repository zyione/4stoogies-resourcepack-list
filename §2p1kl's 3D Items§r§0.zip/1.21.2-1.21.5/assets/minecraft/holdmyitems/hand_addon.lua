local hand = bl and 1 or -1

if (
        I:isOf(item, Items:get("minecraft:netherite_chestplate")) or
        I:isOf(item, Items:get("minecraft:diamond_chestplate")) or
        I:isOf(item, Items:get("minecraft:golden_chestplate")) or
        I:isOf(item, Items:get("minecraft:iron_chestplate")) or
        I:isOf(item, Items:get("minecraft:copper_chestplate")) or
        I:isOf(item, Items:get("minecraft:chainmail_chestplate")) or
        I:isOf(item, Items:get("minecraft:leather_chestplate")) or
        I:isOf(item, Items:get("minecraft:elytra"))
    ) then
    M:moveX(matrices, 0 * hand)
    M:moveY(matrices, -0.82)
    M:moveZ(matrices, -0.210)
    M:rotateX(matrices, 10)
    M:rotateY(matrices, -15 * hand)
    M:rotateZ(matrices, 100 * hand)
end

if (
        I:isOf(item, Items:get("minecraft:netherite_leggings")) or
        I:isOf(item, Items:get("minecraft:diamond_leggings")) or
        I:isOf(item, Items:get("minecraft:golden_leggings")) or
        I:isOf(item, Items:get("minecraft:iron_leggings")) or
        I:isOf(item, Items:get("minecraft:copper_leggings")) or
        I:isOf(item, Items:get("minecraft:chainmail_leggings")) or
        I:isOf(item, Items:get("minecraft:leather_leggings"))
    ) then
    M:moveX(matrices, 0 * hand)
    M:moveY(matrices, -0.82)
    M:moveZ(matrices, -0.210)
    M:rotateX(matrices, 10)
    M:rotateY(matrices, -15 * hand)
    M:rotateZ(matrices, 100 * hand)
end

if (
        I:isOf(item, Items:get("minecraft:creeper_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:guster_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:mojang_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:flow_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:field_masoned_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:bordure_indented_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:flower_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:globe_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:piglin_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:skull_banner_pattern")) or
                I:isOf(item, Items:get("minecraft:name_tag"))
) then
    M:moveX(matrices, 0 * hand)
    M:moveY(matrices, 0.35)
    M:moveZ(matrices, 0)
    M:moveX(matrices, 0 * hand)
    M:rotateX(matrices, 0)
    M:rotateY(matrices, 0 * hand)
end