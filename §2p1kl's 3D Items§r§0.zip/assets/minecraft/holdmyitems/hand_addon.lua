local hand = context.bl and 1 or -1

if (
        I:isOf(context.item, Items:get("minecraft:netherite_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:diamond_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:golden_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:iron_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:copper_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:chainmail_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:leather_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:elytra"))
    ) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, -0.825)
    M:moveZ(context.matrices, -0.265)
    M:rotateX(context.matrices, 23)
    M:rotateY(context.matrices, -6 * hand)
    M:rotateZ(context.matrices, 100 * hand)
    M:scale(context.matrices, 0.9, 0.9, 0.9)
end

if (
        I:isOf(context.item, Items:get("minecraft:netherite_leggings")) or
        I:isOf(context.item, Items:get("minecraft:diamond_leggings")) or
        I:isOf(context.item, Items:get("minecraft:golden_leggings")) or
        I:isOf(context.item, Items:get("minecraft:iron_leggings")) or
        I:isOf(context.item, Items:get("minecraft:copper_leggings")) or
        I:isOf(context.item, Items:get("minecraft:chainmail_leggings")) or
        I:isOf(context.item, Items:get("minecraft:leather_leggings"))
    ) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, -0.825)
    M:moveZ(context.matrices, -0.265)
    M:rotateX(context.matrices, 23)
    M:rotateY(context.matrices, -6 * hand)
    M:rotateZ(context.matrices, 100 * hand)
    M:scale(context.matrices, 0.9, 0.9, 0.9)
end

if (
        I:isOf(context.item, Items:get("minecraft:creeper_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:guster_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:mojang_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:flow_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:field_masoned_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:bordure_indented_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:flower_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:globe_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:piglin_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:skull_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:name_tag")) or
                I:isOf(context.item, Items:get("minecraft:torchflower_seeds"))
) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, -0.825)
    M:moveZ(context.matrices, -0.265)
    M:rotateX(context.matrices, 23)
    M:rotateY(context.matrices, -6 * hand)
    M:rotateZ(context.matrices, 100 * hand)
    M:scale(context.matrices, 0.9, 0.9, 0.9)
end