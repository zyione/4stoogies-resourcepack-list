global.axolotl_anim = 0.001;
global.pufferfish_anim = 0.001;
global.salmon_anim = 0.001;
global.cod_anim = 0.001;
global.tadpole_anim = 0.001;
global.liquid_anim = 0.001;
global.tropical_fish_anim = 0.001;

local hand = context.bl and 1 or -1

if (I:isOf(context.item, Items:get("minecraft:bucket")) or
                I:isOf(context.item, Items:get("minecraft:water_bucket")) or
                I:isOf(context.item, Items:get("minecraft:lava_bucket")) or
                I:isOf(context.item, Items:get("minecraft:milk_bucket")) or
                I:isOf(context.item, Items:get("minecraft:powder_snow_bucket")) or
                I:isOf(context.item, Items:get("minecraft:salmon_bucket")) or
                I:isOf(context.item, Items:get("minecraft:cod_bucket")) or
                I:isOf(context.item, Items:get("minecraft:axolotl_bucket")) or
                I:isOf(context.item, Items:get("minecraft:tropical_fish_bucket")) or
                I:isOf(context.item, Items:get("minecraft:pufferfish_bucket")) or
                I:isOf(context.item, Items:get("minecraft:tadpole_bucket"))
) then
    M:moveX(context.matrices, 0.134 * hand)
    M:moveY(context.matrices, 0.02)
    M:moveZ(context.matrices, -0.146)
    M:rotateX(context.matrices, 14)
    M:scale(context.matrices, 0.9, 0.9, 0.9)
end

if (
                I:isOf(context.item, Items:get("minecraft:netherite_axe")) or
                I:isOf(context.item, Items:get("minecraft:diamond_axe")) or
                I:isOf(context.item, Items:get("minecraft:golden_axe")) or
                I:isOf(context.item, Items:get("minecraft:iron_axe")) or
                I:isOf(context.item, Items:get("minecraft:copper_axe")) or
                I:isOf(context.item, Items:get("minecraft:stone_axe")) or
                I:isOf(context.item, Items:get("minecraft:wooden_axe")) or

                I:isOf(context.item, Items:get("minecraft:netherite_hoe")) or
                I:isOf(context.item, Items:get("minecraft:diamond_hoe")) or
                I:isOf(context.item, Items:get("minecraft:golden_hoe")) or
                I:isOf(context.item, Items:get("minecraft:iron_hoe")) or
                I:isOf(context.item, Items:get("minecraft:copper_hoe")) or
                I:isOf(context.item, Items:get("minecraft:stone_hoe")) or
                I:isOf(context.item, Items:get("minecraft:wooden_hoe")) or

                I:isOf(context.item, Items:get("crossbow")) or
                I:isOf(context.item, Items:get("crossbow_pulling_0")) or
                I:isOf(context.item, Items:get("crossbow_pulling_1")) or
                I:isOf(context.item, Items:get("crossbow_pulling_2")) or
                I:isOf(context.item, Items:get("crossbow_arrow")) or
                I:isOf(context.item, Items:get("crossbow_firework")) or
     
                I:isOf(context.item, Items:get("minecraft:stick")) or
                I:isOf(context.item, Items:get("minecraft:debug_stick")) or
                I:isOf(context.item, Items:get("minecraft:brush")) or
                I:isOf(context.item, Items:get("minecraft:brush_brushing_0")) or
                I:isOf(context.item, Items:get("minecraft:brush_brushing_1")) or
                I:isOf(context.item, Items:get("minecraft:brush_brushing_2"))
) then
    M:scale(context.matrices, 0.85, 0.85, 0.85)

end

if (
        I:isOf(context.item, Items:get("minecraft:netherite_sword")) or
                I:isOf(context.item, Items:get("minecraft:diamond_sword")) or
                I:isOf(context.item, Items:get("minecraft:golden_sword")) or
                I:isOf(context.item, Items:get("minecraft:iron_sword")) or
                I:isOf(context.item, Items:get("minecraft:copper_sword")) or
                I:isOf(context.item, Items:get("minecraft:stone_sword")) or
                I:isOf(context.item, Items:get("minecraft:wooden_sword")) or

                I:isOf(context.item, Items:get("minecraft:netherite_pickaxe")) or
                I:isOf(context.item, Items:get("minecraft:diamond_pickaxe")) or
                I:isOf(context.item, Items:get("minecraft:golden_pickaxe")) or
                I:isOf(context.item, Items:get("minecraft:iron_pickaxe")) or
                I:isOf(context.item, Items:get("minecraft:copper_pickaxe")) or
                I:isOf(context.item, Items:get("minecraft:stone_pickaxe")) or
                I:isOf(context.item, Items:get("minecraft:wooden_pickaxe"))
) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, 0.025)
    M:moveZ(context.matrices, 0.120)
    M:rotateX(context.matrices, -19)
    M:rotateY(context.matrices, 180 * hand)
    M:rotateZ(context.matrices, 0 * hand)
    M:scale(context.matrices, 0.85, 0.85, 0.85)
end

if (
         I:isOf(context.item, Items:get("minecraft:netherite_spear")) or
                I:isOf(context.item, Items:get("minecraft:diamond_spear")) or
                I:isOf(context.item, Items:get("minecraft:golden_spear")) or
                I:isOf(context.item, Items:get("minecraft:iron_spear")) or
                I:isOf(context.item, Items:get("minecraft:copper_spear")) or
                I:isOf(context.item, Items:get("minecraft:stone_spear")) or
                I:isOf(context.item, Items:get("minecraft:wooden_spear"))
) then
    M:moveY(context.matrices, 0.215)
    M:scale(context.matrices, 0.85, 0.85, 0.85)
end

if (
                    I:isOf(context.item, Items:get("minecraft:netherite_shovel")) or
                I:isOf(context.item, Items:get("minecraft:diamond_shovel")) or
                I:isOf(context.item, Items:get("minecraft:golden_shovel")) or
                I:isOf(context.item, Items:get("minecraft:iron_shovel")) or
                I:isOf(context.item, Items:get("minecraft:copper_shovel")) or
                I:isOf(context.item, Items:get("minecraft:stone_shovel")) or
                I:isOf(context.item, Items:get("minecraft:wooden_shovel"))
) then
    M:moveX(context.matrices, 0.015 * hand)
    M:moveZ(context.matrices, 0.1)
    M:rotateX(context.matrices, 90)
    M:rotateY(context.matrices, -90 * hand)
    M:rotateZ(context.matrices, 90 * hand)
        M:scale(context.matrices, 0.85, 0.85, 0.85)
end

if (    
        I:isOf(context.item, Items:get("minecraft:mace"))
) then
        M:moveY(context.matrices, 0.1 * hand)
        M:scale(context.matrices, 0.75, 0.75, 0.75)
end

if (
        I:isOf(context.item, Items:get("minecraft:fishing_rod")) or
        I:isOf(context.item, Items:get("minecraft:fishing_rod_cast")) or
        I:isOf(context.item, Items:get("minecraft:carrot_on_a_stick")) or
        I:isOf(context.item, Items:get("minecraft:warped_fungus_on_a_stick"))
) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, 0)
    M:moveZ(context.matrices, -0.08)
    M:rotateX(context.matrices, -45)
    M:rotateY(context.matrices, 0 * hand)
    M:rotateZ(context.matrices, 0 * hand)
    M:scale(context.matrices, 0.85, 0.85, 0.85)
end

if (
    I:isOf(context.item, Items:get("minecraft:totem_of_undying"))) then
    M:moveX(context.matrices, -0.044 * hand)
    M:moveY(context.matrices, 0.052)
    M:moveZ(context.matrices, 0)
    M:rotateX(context.matrices, -108)
    M:rotateY(context.matrices, 32 * hand)
    M:rotateZ(context.matrices, 116 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:netherite_helmet")) or
        I:isOf(context.item, Items:get("minecraft:diamond_helmet")) or
        I:isOf(context.item, Items:get("minecraft:golden_helmet")) or
        I:isOf(context.item, Items:get("minecraft:iron_helmet")) or
        I:isOf(context.item, Items:get("minecraft:copper_helmet")) or
        I:isOf(context.item, Items:get("minecraft:chainmail_helmet")) or
        I:isOf(context.item, Items:get("minecraft:leather_helmet"))
    ) then
    M:moveX(context.matrices, 0.025 * hand)
    M:moveY(context.matrices, 0.020)
    M:moveZ(context.matrices, 0)
    M:rotateX(context.matrices, 19)
    M:rotateY(context.matrices, 147 * hand)
    M:rotateZ(context.matrices, -18 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:netherite_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:diamond_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:golden_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:iron_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:copper_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:chainmail_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:leather_chestplate")) or
        I:isOf(context.item, Items:get("minecraft:elytra"))
    ) then
    M:moveX(context.matrices, -0.09 * hand)
    M:moveY(context.matrices, -0.09)
    M:moveZ(context.matrices, 0.09)
    M:rotateX(context.matrices, -8.5)
    M:rotateY(context.matrices, 144 * hand)
    M:rotateZ(context.matrices, 100 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:netherite_leggings")) or
        I:isOf(context.item, Items:get("minecraft:diamond_leggings")) or
        I:isOf(context.item, Items:get("minecraft:golden_leggings")) or
        I:isOf(context.item, Items:get("minecraft:iron_leggings")) or
        I:isOf(context.item, Items:get("minecraft:copper_leggings")) or
        I:isOf(context.item, Items:get("minecraft:chainmail_leggings")) or
        I:isOf(context.item, Items:get("minecraft:leather_leggings"))
    ) then
    M:moveX(context.matrices, -0.09 * hand)
    M:moveY(context.matrices, -0.09)
    M:moveZ(context.matrices, 0.09)
    M:rotateX(context.matrices, -8.5)
    M:rotateY(context.matrices, 144 * hand)
    M:rotateZ(context.matrices, 100 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:netherite_boots")) or
        I:isOf(context.item, Items:get("minecraft:diamond_boots")) or
        I:isOf(context.item, Items:get("minecraft:golden_boots")) or
        I:isOf(context.item, Items:get("minecraft:iron_boots")) or
        I:isOf(context.item, Items:get("minecraft:copper_boots")) or
        I:isOf(context.item, Items:get("minecraft:chainmail_boots")) or
        I:isOf(context.item, Items:get("minecraft:leather_boots"))
    ) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, 0.2)
    M:moveZ(context.matrices, 0.2)
    M:rotateX(context.matrices, -60)
    M:rotateY(context.matrices, 0 * hand)
    M:rotateZ(context.matrices, 0 * hand)
end

if  (
        I:isOf(context.item, Items:get("minecraft:shears"))) then
    if context.bl then
    M:moveX(context.matrices, 0)
    M:moveY(context.matrices, 0)
    M:moveZ(context.matrices, 0)
    M:rotateX(context.matrices, 0)
    M:rotateY(context.matrices, 0)
    M:rotateZ(context.matrices, -50)
    else
    M:moveX(context.matrices, 0)
    M:moveY(context.matrices, 0)
    M:moveZ(context.matrices, 0)
    M:rotateX(context.matrices, 10)
    M:rotateY(context.matrices, -10)
    M:rotateZ(context.matrices, -50)
    end
end

if (
        I:isOf(context.item, Items:get("minecraft:turtle_helmet"))
    ) then
    M:moveX(context.matrices, 0.084 * hand)
    M:moveY(context.matrices, -0.02)
    M:moveZ(context.matrices, -0.14)
    M:rotateX(context.matrices, -121.8)
    M:rotateY(context.matrices, 8 * hand)
    M:rotateZ(context.matrices, 148 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:glass_bottle")) or
        I:isOf(context.item, Items:get("minecraft:potion")) or
        I:isOf(context.item, Items:get("minecraft:splash_potion")) or
        I:isOf(context.item, Items:get("minecraft:lingering_potion")) or
        I:isOf(context.item, Items:get("minecraft:honey_bottle")) or
        I:isOf(context.item, Items:get("minecraft:ominous_bottle")) or
        I:isOf(context.item, Items:get("minecraft:dragon_breath"))
    ) then
    M:moveY(context.matrices, 0.28)
    M:moveZ(context.matrices, 0.135)
    M:rotateX(context.matrices, -72)
    M:scale(context.matrices, 0.9, 0.9, 0.9)
end

if (
        I:isOf(context.item, Items:get("minecraft:creeper_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:guster_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:mojang_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:flow_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:field_masoned_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:bordure_indented_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:flower_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:globe_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:piglin_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:skull_banner_pattern"))
) then
    M:moveX(context.matrices, -0.09 * hand)
    M:moveY(context.matrices, -0.09)
    M:moveZ(context.matrices, 0.09)
    M:rotateX(context.matrices, -8.5)
    M:rotateY(context.matrices, 144 * hand)
    M:rotateZ(context.matrices, 100 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:name_tag"))
) then
    M:moveX(context.matrices, -0.05 * hand)
    M:moveY(context.matrices, -0.09)
    M:moveZ(context.matrices, 0.09)
    M:rotateX(context.matrices, -8.5)
    M:rotateY(context.matrices, 144 * hand)
    M:rotateZ(context.matrices, 100 * hand)
end

if (
        I:isOf(context.item, Items:get("minecraft:torchflower_seeds"))
) then
    M:moveX(context.matrices, -0.135 * hand)
    M:moveY(context.matrices, -0.1)
    M:rotateX(context.matrices, 93)
    M:rotateY(context.matrices, 76 * hand)
    M:rotateZ(context.matrices, 5 * hand)
end